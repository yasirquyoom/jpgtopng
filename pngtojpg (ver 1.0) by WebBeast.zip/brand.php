<?php
	$domainName = "ConvertPNGtoJPGOnline.com";
?>